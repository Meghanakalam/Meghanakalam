const http = require('http');
const url = require('url');
const qs = require('querystring');

const server = http.createServer((req, res) => {
  const { pathname } = url.parse(req.url, true);
  if (pathname === '/meghanakalamMathGame') { 
    res.writeHead(200, {'Content-Type': 'text/html'});
    const num1 = Math.floor(Math.random() * 10);
    const num2 = Math.floor(Math.random() * 10);
    const question = `How much is ${num1} times ${num2} ?`;
    res.write(`<h1>${question}</h1>`);
    res.write(`Enter your answer: `)
    res.write('<form method="POST" action="/submit">');
    res.write(`<p> <input type="hidden" name="num1" value=${num1}></p>`);
    res.write(`<p> <input type="hidden" name="num2" value=${num2}></p>`);
    res.write(`<p><input type="number" name="answer" /></p>`);
    res.write('<p><button type="submit">Check Answer</button></p>');
    res.write('<p><button type="button" onclick="location.href=\'/meghanakalamMathGame\'">New Question</button></p>');
    res.write('</form>');
    res.end();
  } else if (pathname === '/submit' && req.method === 'POST') {

    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {

      const { answer,num1,num2 } = qs.parse(body);
      const correct = num1 * num2;
 console.log(num1,num2);
      res.writeHead(200, {'Content-Type': 'text/html'});
      if (parseInt(answer) === correct) {
        res.write('<p>Very good!</p>');
      } else {
        res.write('<p>No, please try again.</p>');
      }
      res.write('<p><button type="button" onclick="location.href=\'/meghanakalamMathGame\'">New Question</button></p>');
      res.end();
    });
  } else {
    res.writeHead(404, {'Content-Type': 'text/plain'});
    res.end('Page not found');
  }
});

server.listen(53701, () => {
  console.log('Server listening on port 53701');
});
