//http://localhost:53701/meghanakallamMathGame

const express = require('express');
const app = express();

app.get('/meghanakallamMathGame', (req, res) => {
  res.send(`<><h1>How much is ${Math.floor((Math.random()*10))} times ${Math.floor((Math.random()*10))} ?</h1><div><p>Enter your answer</p>
  <input type="number"/>
  </div></>`);
});

// app.listen(53701, () => {
//   console.log('Server listening on port 53701!');
// });
